import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContentModule } from '@alfresco/adf-content-services';
import { PageLayoutModule, SharedToolbarModule } from '@alfresco/aca-shared';
import { FileVersionsComponent } from './components/file-versions/file-versions.component';
import { ExtensionService, provideExtensionConfig } from '@alfresco/adf-extensions';
import { CoreModule, InfoDrawerModule, TRANSLATION_PROVIDER } from '@alfresco/adf-core';
import { LibraryVersionColumnComponent } from './components/library-version-column/library-version-column.component';
import { ExtensionSharedModule } from '../../../content-ee/content-services-extension/src/lib/components/shared';
import { ContentServiceExtensionModule } from '@alfresco/aca-content';
import { isFileVersions, selectedOne } from './rules/delta.rules';
import { DeltaEffects } from './store/effects/delta.effects';
import { DeltaVersionService } from './services/delta-version.service';
import { EffectsModule } from '@ngrx/effects';

export const effects = [DeltaEffects];

@NgModule({
  imports: [
    CommonModule,
    CoreModule,
    ContentModule.forChild(),
    PageLayoutModule, 
    SharedToolbarModule,
    ExtensionSharedModule,
    InfoDrawerModule,
    ContentServiceExtensionModule,
    EffectsModule.forFeature(effects),
  ],
  declarations: [
    FileVersionsComponent,
    LibraryVersionColumnComponent,
  ],
  providers: [
    {
      provide: TRANSLATION_PROVIDER,
      multi: true,
      useValue: {
          name: 'delta-extension',
          source: 'assets/delta-extension',
      },
    },
    provideExtensionConfig(['delta-extension.json']),
    DeltaVersionService,
  ]
})
export class DeltaExtensionModule {

  constructor(extensions: ExtensionService) {
    extensions.setComponents({
      'delta.components.file-versions': FileVersionsComponent,
      'delta.files.column.version': LibraryVersionColumnComponent,
    });
    extensions.setEvaluators({
      'delta.rule.isFileVersions': isFileVersions,
      'delta.rule.versions.selected.one': selectedOne,
    });
  }

}
