import { ChangeDetectionStrategy, Component, ElementRef, OnDestroy, OnInit, ViewEncapsulation } from "@angular/core";
import { NameColumnComponent, NodesApiService } from '@alfresco/adf-content-services';
import { Router } from "@angular/router";

@Component({
    template: `
        <span
            role="link"
            [attr.aria-label]="'NAME_COLUMN_LINK.ACCESSIBILITY.ARIA_LABEL' | translate:{
                name:  displayText$ | async
            }"
            class="adf-datatable-cell-value"
            title="{{ node | adfNodeNameTooltip }}"
            (click)="onClick()">
            {{ displayText$ | async }}
        </span>`,
    changeDetection: ChangeDetectionStrategy.OnPush,
    encapsulation: ViewEncapsulation.None,
    host: { class: 'adf-datatable-content-cell adf-name-column' },
})
export class LibraryVersionColumnComponent extends NameColumnComponent implements OnInit, OnDestroy {

    constructor(public elementRef: ElementRef,
        nodesService: NodesApiService,
        private router: Router) {
        super(elementRef, nodesService);
    }

    override ngOnInit(): void {
        super.ngOnInit();
        this.displayText$.next(this.getValue());
    }

    override onClick(): void {
        this.router.navigate([
            '/nodes', 
            this.node?.entry?.id, 
            'versions' 
        ]);
    }

    getValue() { 
        if (this.node?.entry?.isFile && this.node?.entry?.properties['cm:versionLabel']) {
            let version: string = this.node?.entry?.properties['cm:versionLabel'];
            return version.substring(0, version.indexOf("."));
        }
        return ' ';
    }

}