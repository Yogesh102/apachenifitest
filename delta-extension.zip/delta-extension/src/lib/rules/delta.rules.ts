import { RuleContext } from "@alfresco/adf-extensions";

export function selectedOne(context: RuleContext): boolean {
    return context.selection?.count == 1;
}

export function isFileVersions(context: RuleContext): boolean | any {
    const { url } = context.navigation;
    return url?.startsWith('/nodes/') && url?.includes('/versions');
}
