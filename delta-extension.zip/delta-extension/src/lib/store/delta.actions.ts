import { Action } from '@ngrx/store';
import { RevertBody, Version } from '@alfresco/js-api';

export const VIEW_FILE_VERSION = 'VIEW_FILE_VERSION';
export class ViewVersionAction implements Action {
    readonly type = VIEW_FILE_VERSION;
    constructor(public version: Version) {}
}

export const DOWNLOAD_FILE_VERSION = 'DOWNLOAD_FILE_VERSION';
export class DownloadVersionAction implements Action {
    readonly type = DOWNLOAD_FILE_VERSION;
    constructor(public version: Version) {}
}

export const RESTORE_FILE_VERSION = 'RESTORE_FILE_VERSION';
export class RestoreVersionAction implements Action {
    readonly type = RESTORE_FILE_VERSION;
    constructor(public version: Version, public revertBody: RevertBody) {}
}

export const DELETE_FILE_VERSION = 'DELETE_FILE_VERSION';
export class DeleteVersionAction implements Action {
    readonly type = DELETE_FILE_VERSION;
    constructor(public version: Version) {}
}

export const RELOAD_VERSIONS = 'RELOAD_VERSIONS';
export class ReloadVersionsAction implements Action {
    readonly type = RELOAD_VERSIONS;
}
