import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { DELETE_FILE_VERSION, DOWNLOAD_FILE_VERSION, DeleteVersionAction, DownloadVersionAction, RESTORE_FILE_VERSION, RestoreVersionAction } from '../delta.actions';
import { take, tap } from 'rxjs/operators';
import { DeltaVersionService } from '../../services/delta-version.service';
import { Store } from '@ngrx/store';
import { getAppSelection } from '@alfresco/aca-shared/store';
import { Observable } from 'rxjs';
import { SelectionState } from '@alfresco/adf-extensions';
import { Version } from '@alfresco/js-api';

@Injectable()
export class DeltaEffects {
    constructor(
        private store: Store<any>,
        private actions$: Actions,
        private versionService: DeltaVersionService
    ) { }

    restoreVersion$ = createEffect(() => this.actions$.pipe(
        ofType<RestoreVersionAction>(RESTORE_FILE_VERSION),
        tap((action: any) => {
            if (action?.version) {
                this.versionService.restore(action.version, action.revertBody);
            } else {
                this.getFromSelection().subscribe((selection) => {
                    this.versionService.restore(selection.file?.entry as Version, { majorVersion: true, comment: '' });
                })
            }
        })
    ), { dispatch: false });

    deleteVersion$ = createEffect(() => this.actions$.pipe(
        ofType<DeleteVersionAction>(DELETE_FILE_VERSION),
        tap((action: any) => {
            if (action?.version) {
                this.versionService.openDeleteConfirmation(action.version);
            } else {
                this.getFromSelection().subscribe((selection) => {
                    this.versionService.openDeleteConfirmation(selection.file?.entry as Version);
                })
            }
        })
    ), { dispatch: false });

    downloadVersion$ = createEffect(() => this.actions$.pipe(
        ofType<DownloadVersionAction>(DOWNLOAD_FILE_VERSION),
        tap((action: any) => {
            if (action?.version) {
                this.versionService.downloadVersion(action.version);
            } else {
                this.getFromSelection().subscribe((selection) => {
                    this.versionService.downloadVersion(selection.file?.entry as Version);
                })
            }
        })
    ), { dispatch: false });

    getFromSelection(): Observable<SelectionState> {
        return this.store
            .select(getAppSelection)
            .pipe(take(1));
    }
}
