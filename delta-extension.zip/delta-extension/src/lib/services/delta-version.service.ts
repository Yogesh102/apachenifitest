import { ConfirmDialogComponent, ContentService, ContentVersionService } from "@alfresco/adf-content-services";
import { AlfrescoApiService, NotificationService } from "@alfresco/adf-core";
import { ContentApi, Node, NodesApi, RevertBody, Version, VersionsApi } from "@alfresco/js-api";
import { Injectable, OnDestroy } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { Store } from "@ngrx/store";
import { ReloadVersionsAction } from "../store/delta.actions";
import { Subject } from "rxjs";
import { Actions, ofType } from "@ngrx/effects";
import { AppActionTypes, SetCurrentFolderAction } from "@alfresco/aca-shared/store";
import { takeUntil } from "rxjs/operators";

@Injectable({
    providedIn: 'root',
})
export class DeltaVersionService implements OnDestroy {

    private _contentApi: ContentApi | undefined;
    get contentApi(): ContentApi {
        this._contentApi = this._contentApi ?? new ContentApi(this.alfrescoApi.getInstance());
        return this._contentApi;
    }

    private _versionsApi: VersionsApi | undefined;
    get versionsApi(): VersionsApi {
        this._versionsApi = this._versionsApi ?? new VersionsApi(this.alfrescoApi.getInstance());
        return this._versionsApi;
    }

    private _nodesApi: NodesApi | undefined;
    get nodesApi(): NodesApi {
        this._nodesApi = this._nodesApi ?? new NodesApi(this.alfrescoApi.getInstance());
        return this._nodesApi;
    }

    node: Node | undefined;
    onDestroy$ = new Subject();

    constructor(
        protected store: Store<any>,
        protected actions$: Actions,
        private alfrescoApi: AlfrescoApiService,
        private contentService: ContentService,
        private contentVersionService: ContentVersionService,
        private notifications: NotificationService,
        private dialog: MatDialog,
    ) {
        this.actions$.pipe(
            ofType<SetCurrentFolderAction>(AppActionTypes.SetCurrentFolder),
            takeUntil(this.onDestroy$),
        ).subscribe((action) => this.node = action.payload);
    }

    canUpdate(): boolean {
        return this.contentService.hasAllowableOperations(this.node!, 'update');
    }

    canDelete(): boolean {
        return this.contentService.hasAllowableOperations(this.node!, 'delete');
    }

    restore(version: Version, revertBody: RevertBody) {
        if (this.canUpdate()) {
            this.versionsApi
                .revertVersion(this.node!.id, version.id, revertBody)
                .then(() => {
                    this.notifications.showInfo("Version Reverted Successfully");
                    this.store.dispatch(new ReloadVersionsAction());
                })
                .catch((err) => {
                    this.notifications.showError("Error while Reverting Version");
                    console.error(err);
                });
        }
    }

    openDeleteConfirmation(version: Version) {
        const dialogRef = this.dialog.open(ConfirmDialogComponent, {
            data: {
                title: 'ADF_VERSION_LIST.CONFIRM_DELETE.TITLE',
                message: 'ADF_VERSION_LIST.CONFIRM_DELETE.MESSAGE',
                yesLabel: 'ADF_VERSION_LIST.CONFIRM_DELETE.YES_LABEL',
                noLabel: 'ADF_VERSION_LIST.CONFIRM_DELETE.NO_LABEL'
            },
            minWidth: '250px'
        });

        dialogRef
            .afterClosed()
            .subscribe((result: any) => {
                if (result) {
                    this.versionsApi.deleteVersion(this.node!.id, version.id)
                        .then(() => this.store.dispatch(new ReloadVersionsAction()));
                }
            },
                (error) => {
                    this.notifications.showError("Could not Delete file Version " + version.id);
                    console.error(error);
                });
    }

    downloadVersion(version: Version) {
        this.contentVersionService
            .getVersionContentUrl(this.node!.id, version.id, true)
            .subscribe(
                (versionDownloadUrl: any) => this.downloadContent(versionDownloadUrl),
                (error) => {
                    this.notifications.showError("Could not Download file Version " + version.id);
                    console.error(error);
                });
    }

    downloadContent(url: string) {
        if (url) {
            const link = document.createElement('a');

            link.style.display = 'none';
            link.href = url;

            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

    ngOnDestroy(): void {
        this.onDestroy$.next();
        this.onDestroy$.complete();
    }
}
