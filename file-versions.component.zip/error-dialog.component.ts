import { Component, Inject, AfterViewInit, ElementRef, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AuthenticationService, AppConfigService } from '@alfresco/adf-core';

@Component({
  selector: 'app-error-dialog',
  template: `
    <h2 mat-dialog-title>Error</h2>
    <mat-dialog-content>
      <p>{{ data.message }}</p>
      <p>If not redirected, <a [href]="viewerUrl" target="_blank">click here</a></p>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="closeDialog()">Close</button>
    </mat-dialog-actions>

    <!-- Auto-submitting Form -->
    <form #aevForm method="get" [action]="viewerUrl" target="_blank"></form>
  `,
  styles: [`
    a {
      color: #0078d4;
      text-decoration: none;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }
  `]
})
export class ErrorDialogComponent implements AfterViewInit {
  @ViewChild('aevForm', { static: true }) aevForm!: ElementRef<HTMLFormElement>;
  viewerUrl: string = '';

  constructor(
    public dialogRef: MatDialogRef<ErrorDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private authService: AuthenticationService,
    private appConfig: AppConfigService,
  ) {}

  ngOnInit() {
    
    const ecmTicket = this.authService.getTicketEcm();
    console.log("ECM ticket " + ecmTicket );
    if (ecmTicket) {
      this.viewerUrl = this.generateAEVLink(ecmTicket);
    }
    
  }

  ngAfterViewInit() {
    // Automatically submit the form when the dialog loads
  //  if (this.aevForm && this.viewerUrl) {
   //   this.aevForm.nativeElement.submit();
   // }
  }

  generateAEVLink(ticket: string): string {
    const baseUrl = this.appConfig.get('ecmHost') + '/OpenAnnotate/login/external.htm?';
    const node= "workspace%3A%2F%2FSpacesStore%2F" + this.data.nodeId
    const params = new URLSearchParams({
      username: this.authService.getEcmUsername() || '',
      mode: this.data.mode || 'readOnly',
      ticket: ticket,
      docId: node
    }).toString();

    return `${baseUrl}?${params}`;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }
}
