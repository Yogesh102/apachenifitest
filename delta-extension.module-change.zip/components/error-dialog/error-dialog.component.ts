import { Component, Inject } from '@angular/core';
import { AppConfigService } from '@alfresco/adf-core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-error-dialog',
  template: `
    <h2 mat-dialog-title>INFO</h2>
    <mat-dialog-content>
      <p>{{ data.message }}</p>
      <p *ngIf="data.nodeId">
        <a [href]="generateAEVLink(data.nodeId)" target="_blank" rel="noopener noreferrer">
          View in AEV
        </a>
      </p>
    </mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="closeDialog()">Close</button>
    </mat-dialog-actions>
  `,
  styles: [`
    a {
      color: #0078d4;
      text-decoration: none;
      font-weight: bold;
    }
    a:hover {
      text-decoration: underline;
    }
  `]
})
export class ErrorDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<ErrorDialogComponent>,
    private appConfig: AppConfigService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  generateAEVLink(nodeId: string): string {
    const baseUrl = this.appConfig.get('ecmHost') + '/OpenAnnotate/viewer.html';
    return `${baseUrl}?docId=${nodeId}`;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }
}
