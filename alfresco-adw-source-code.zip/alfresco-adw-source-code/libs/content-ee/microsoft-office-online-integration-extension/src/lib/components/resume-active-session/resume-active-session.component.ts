/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { Component, OnInit, OnDestroy, ElementRef, ViewEncapsulation } from '@angular/core';
import { NodesApiService, NameColumnComponent } from '@alfresco/adf-content-services';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
    selector: 'ooi-resume-active-session',
    templateUrl: './resume-active-session.component.html',
    styleUrls: ['./resume-active-session.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class ResumeActiveSessionComponent extends NameColumnComponent implements OnInit, OnDestroy {
    private onDestroy$$ = new Subject<boolean>();
    private iconPath = './assets/icons/ic_pencil.svg';

    constructor(element: ElementRef, private nodesService: NodesApiService) {
        super(element, nodesService);
    }

    ngOnInit() {
        this.updateValue();

        this.nodesService.nodeUpdated.pipe(takeUntil(this.onDestroy$$)).subscribe((node: any) => {
            const row = this.context.row;
            if (row) {
                const { entry } = row.node;
                const currentId = entry.nodeId || entry.id;
                const updatedId = node.nodeId || node.id;

                if (currentId === updatedId) {
                    entry.name = node.name;
                    row.node = { entry };
                    this.updateValue();
                }
            }
        });
    }

    get getIconPath(): string {
        return this.iconPath;
    }

    isBeingEditedInMicrosoft(): boolean {
        return (
            this.node?.entry?.aspectNames?.indexOf('ooi:editingInMSOffice') !== -1 &&
            this.node?.entry?.properties?.['ooi:sessionNodeId'] === this.node?.entry?.id &&
            this.node?.entry?.properties?.['ooi:acsSessionOwner'] === this.node?.entry?.properties?.['cm:lockOwner']?.id &&
            localStorage.getItem('microsoftOnline') !== null
        );
    }

    ngOnDestroy() {
        super.ngOnDestroy();

        this.onDestroy$$.next(true);
        this.onDestroy$$.complete();
    }
}
