/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { NgModule } from '@angular/core';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import {
    AlfrescoApiService,
    AppConfigService,
    TranslationService,
    AlfrescoApiServiceMock,
    AppConfigServiceMock,
    TranslationMock,
    TRANSLATION_PROVIDER
} from '@alfresco/adf-core';
import { API_CLIENT_FACTORY_TOKEN, ApiClientFactory, ApiClientsService, Constructor } from '@alfresco/adf-core/api';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { TranslateModule, TranslateStore, TranslateService } from '@ngx-translate/core';
import { HttpClientModule } from '@angular/common/http';
import * as fromProcessServices from '../store/reducers/process-services.reducer';

class MockApiClientFactory implements ApiClientFactory {
    create<T>(apiClass: Constructor<T>): T {
        return new apiClass();
    }
}

@NgModule({
    imports: [
        NoopAnimationsModule,
        RouterTestingModule,
        HttpClientModule,
        StoreModule.forRoot({}),
        StoreModule.forFeature(fromProcessServices.featureKey, fromProcessServices.reducer),
        EffectsModule.forRoot([]),
        TranslateModule.forRoot(),
    ],
    providers: [
        TranslateStore,
        TranslateService,
        ApiClientsService,
        { provide: API_CLIENT_FACTORY_TOKEN, useClass: MockApiClientFactory },
        { provide: AlfrescoApiService, useClass: AlfrescoApiServiceMock },
        { provide: AppConfigService, useClass: AppConfigServiceMock },
        { provide: TranslationService, useClass: TranslationMock },
        {
            provide: TRANSLATION_PROVIDER,
            multi: true,
            useValue: {
                name: 'process-services-extension',
                source: 'assets',
            },
        },
    ],
})
export class ProcessServicesTestingModule {}
