/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskMetadataExtComponent } from './components/task-metadata-ext.component';
import { TranslateModule } from '@ngx-translate/core';
import { CoreModule, MaterialModule } from '@alfresco/adf-core';
import { PageLayoutModule } from '@alfresco/aca-shared';
import { ProcessModule } from '@alfresco/adf-process-services';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
    declarations: [TaskMetadataExtComponent],
    exports: [TaskMetadataExtComponent],
    imports: [
        CommonModule,
        MaterialModule,
        FormsModule,
        ReactiveFormsModule,
        TranslateModule,
        CoreModule,
        PageLayoutModule,
        ProcessModule
    ]
})
export class TaskMetadataModule {}
