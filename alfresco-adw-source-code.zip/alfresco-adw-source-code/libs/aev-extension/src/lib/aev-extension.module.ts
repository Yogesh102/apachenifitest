import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { provideExtensionConfig } from '@alfresco/adf-extensions';
import { AevViewerComponent } from './aev-viewer/aev-viewer.component';
import { ExtensionService } from '@alfresco/adf-extensions';

@NgModule({
  imports: [CommonModule],
  providers: [
    provideExtensionConfig(['aev-extension.json'])
  ],
  declarations: [
    AevViewerComponent
  ]
})
export class AevExtensionModule {

  constructor(extensions: ExtensionService) {
    extensions.setComponents({
      'aev.extension.components.aev-viewer': AevViewerComponent,
    });
  }

}
