import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-aev-viewer',
  template: './aev-viewer.component.html',
  //template: `<button (click)="openAev()">Open in AEV</button>`,
  styles: []
})
export class AevViewerComponent {
  @Input() nodeId: string;

  ngOnInit(): void {
    //this.aevUrl = `https://www.w3schools.com`;
  }

  openAev(): void {
    const aevUrl = `https://www.w3schools.com`;
    window.open(aevUrl, '_blank'); // Opens in a new tab
  }
}