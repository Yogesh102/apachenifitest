import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AevViewerComponent } from './aev-viewer.component';

describe('AevViewerComponent', () => {
  let component: AevViewerComponent;
  let fixture: ComponentFixture<AevViewerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AevViewerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AevViewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
