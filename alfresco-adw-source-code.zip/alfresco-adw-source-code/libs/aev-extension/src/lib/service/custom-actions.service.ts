import { Injectable } from '@angular/core';
import { ContentActionRef } from '@alfresco/adf-content-services';

@Injectable({
  providedIn: 'root'
})
export class CustomActionsService {
  getCustomActions(): ContentActionRef[] {
    return [
      {
        id: 'aev.viewer',
        title: 'View in AEV',
        icon: 'visibility',
        handler: (context) => {
          console.log('DEBUG: Action Context:', context);

          if (!context || !context.selection || context.selection.length === 0) {
            console.error('Error: No valid document selected.');
            return;
          }

          const node = context.selection[0]; // Get the first selected node

          if (node?.entry?.id) {
            const aevUrl = `https://localhost:8080/OpenAnnotate?nodeRef=${node.entry.id}`;
            window.open(aevUrl, '_blank'); // Open AEV in a new tab
          } else {
            console.error('Error: NodeRef is missing or invalid', node);
          }
        }
      }
    ];
  }
}
