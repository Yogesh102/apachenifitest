/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { Routes } from '@angular/router';
import { BlankPageComponent } from '@alfresco/adf-core';
import { LoginComponent } from './components/login/login.component';

export const APP_ROUTES: Routes = [
  {
    path: 'blank',
    component: BlankPageComponent
  },
  {
    path: 'login',
    component: LoginComponent,
    data: {
      title: 'APP.SIGN_IN'
    }
  }
];
