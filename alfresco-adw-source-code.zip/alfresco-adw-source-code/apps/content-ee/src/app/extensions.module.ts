/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { NgModule } from '@angular/core';

import { AosExtensionModule } from '@alfresco/aca-content/ms-office';
import { RecordModule } from '@alfresco/adf-governance';
import { ContentServicesExtensionModule } from '@alfresco/adf-content-services-extension';
import { ProcessServicesExtensionModule } from '@alfresco/adf-process-services-extension';
import { AcaAboutModule, DEV_MODE_TOKEN, PACKAGE_JSON } from '@alfresco/aca-content/about';
import { ExtensionsOrderExtensionModule } from '@alfresco/adf-extensions-order-extension';
import { MicrosoftOfficeOnlineIntegrationExtensionModule } from '@alfresco/microsoft-office-online-integration-extension';
import { environment } from '../environments/environment';
import { AevExtensionModule } from '../../../../libs/aev-extension/src';
import packageJson from 'package.json';

@NgModule({
    imports: [
        AosExtensionModule,
        AcaAboutModule,
        RecordModule,
        ProcessServicesExtensionModule,
        ContentServicesExtensionModule,
        ExtensionsOrderExtensionModule,
        MicrosoftOfficeOnlineIntegrationExtensionModule,
        AevExtensionModule,
    ],
    providers: [
        { provide: PACKAGE_JSON, useValue: packageJson },
        { provide: DEV_MODE_TOKEN, useValue: !environment.production },
    ]
})
export class AppExtensionsModule {

   
}
