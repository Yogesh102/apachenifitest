/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { Component, Input, ViewEncapsulation } from '@angular/core';
import { NodeEntry } from '@alfresco/js-api';
import { isPendingRestore, isRestored, isStoredInGlacier } from '../../rules/glacier-evaluator';

@Component({
    selector: 'aga-glacier-icon',
    templateUrl: './icon.component.html',
    encapsulation: ViewEncapsulation.None
})
export class IconComponent {
    @Input()
    node: NodeEntry;

    public isStoredNode(): boolean {
        return isStoredInGlacier(this.node);
    }

    public isPendingRestoreNode(): boolean {
        return isPendingRestore(this.node);
    }

    public isRestoredNode(): boolean {
        return isRestored(this.node);
    }
}
