/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TaskDetailsExtComponent } from './components/task-details-ext.component';
import { ExtensionService } from '@alfresco/adf-extensions';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';
import { CoreModule, MaterialModule } from '@alfresco/adf-core';
import { PageLayoutModule } from '@alfresco/aca-shared';
import { ProcessModule } from '@alfresco/adf-process-services';
import { TaskMetadataModule } from '../task-metadata/task-metadata.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EffectsModule } from '@ngrx/effects';
import { TaskDetailsExtEffect } from './effects/task-details-ext.effect';

@NgModule({
    declarations: [TaskDetailsExtComponent],
    imports: [
        CommonModule,
        MaterialModule,
        FormsModule,
        ReactiveFormsModule,
        MatIconModule,
        TranslateModule,
        CoreModule,
        PageLayoutModule,
        ProcessModule,
        TaskMetadataModule,
        EffectsModule.forFeature([TaskDetailsExtEffect]),
    ]
})
export class TaskDetailsModule {
    constructor(extensions: ExtensionService) {
        extensions.setComponents({
            'process-services-plugin.components.task-details-ext': TaskDetailsExtComponent,
        });
    }
}
