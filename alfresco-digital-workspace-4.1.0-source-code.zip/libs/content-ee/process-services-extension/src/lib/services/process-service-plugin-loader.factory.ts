/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { ExtensionLoaderCallback } from '@alfresco/aca-shared';
import { tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { ProcessExtensionService } from './process-extension.service';
import { isProcessServicePluginEnabled } from '../rules/process-services.rules';
import { of } from 'rxjs';
import { updateProcessServiceHealth } from '../store/actions/process-services-health.actions';

export function processServicePluginLoaderFactory(processExtensionService: ProcessExtensionService, store: Store<any>): ExtensionLoaderCallback {
    return () => {
        if (!isProcessServicePluginEnabled()) {
            return of(true);
        }

        return processExtensionService.checkBackendHealth().pipe(
            tap((health) => {
                store.dispatch(
                    updateProcessServiceHealth({
                        health,
                    })
                );
            })
        );
    };
}
