/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { Injectable } from '@angular/core';
import { AppConfigService } from '@alfresco/adf-core';
import { Subject } from 'rxjs';

export class MsalConfigModel {
    isActive: boolean;
    auth: {
        clientId: string;
        authority: string;
        redirectUri: string;
        navigateToLoginRequestUrl: boolean;
        msHost: string;
    };
    cache: {
        cacheLocation: string;
        storeAuthStateInCookie: boolean;
    };
}

@Injectable({
    providedIn: 'root',
})
export class MicrosoftExtensionService {
    private onLoad = new Subject<MsalConfigModel>();
    onLoad$ = this.onLoad.asObservable();

    constructor(private appConfigService: AppConfigService) {
        this.appConfigService.onLoad
            .subscribe(() => {
                const msalConfig = this.getConfiguration();

                if (msalConfig.isActive) {
                    this.enablePlugin();
                } else {
                    this.disablePlugin();
                }

                this.onLoad.next(msalConfig);
            });
    }

    getConfiguration(): MsalConfigModel {
        const isPluginActive = this.appConfigService.get<string>('plugins.microsoftOnline', 'false') === 'true';

        return {
            isActive: isPluginActive,
            auth: {
                clientId: isPluginActive ? this.appConfigService.get('msOnline.msClientId', '') : '',
                authority: isPluginActive ? this.appConfigService.get('msOnline.msAuthority', '') : '',
                redirectUri: isPluginActive ? this.appConfigService.get('msOnline.msRedirectUri', '') : '',
                msHost: isPluginActive ? this.appConfigService.get('msOnline.msHost', '') : '',
                navigateToLoginRequestUrl: true,
            },
            cache: {
                cacheLocation: 'localStorage',
                storeAuthStateInCookie: false,
            },
        };
    }

    isEnabled(): boolean {
        return localStorage.getItem('microsoftOnline') === 'true';
    }

    enablePlugin() {
        if (localStorage) {
            localStorage.setItem('microsoftOnline', 'true');
        }
    }

    disablePlugin() {
        localStorage.removeItem('microsoftOnline');
    }
}
