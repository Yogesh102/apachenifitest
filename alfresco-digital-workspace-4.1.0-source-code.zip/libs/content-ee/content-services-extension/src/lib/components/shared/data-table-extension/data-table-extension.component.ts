/*
 * Copyright © 2005-2023 Hyland Software, Inc. and its affiliates. All rights reserved.
 *
 * License rights for this program may be obtained from Hyland Software, Inc.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

import { AfterContentInit, Component, EventEmitter, Input, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import {
    AppConfigService,
    DataRowEvent,
    DataTableComponent,
    DataTableSchema,
    ShowHeaderMode,
    ThumbnailService
} from '@alfresco/adf-core';
import { ContentService, NodePaging, ShareDataTableAdapter } from '@alfresco/adf-content-services';
import { Store } from '@ngrx/store';
import { AppStore, SetSelectedNodesAction } from '@alfresco/aca-shared/store';

@Component({
    selector: 'adw-data-table-extension',
    templateUrl: './data-table-extension.component.html',
    encapsulation: ViewEncapsulation.None,
})
export class DataTableExtensionComponent extends DataTableSchema implements AfterContentInit {
    static PRESET_KEY = 'extension.preset';

    @Input()
    loading = true;

    @Input()
    showHeader: ShowHeaderMode = ShowHeaderMode.Always;

    @Input()
    selectionMode = 'multiple';

    @Input()
    contextMenu = false;

    @Input()
    set items(nodePaging: NodePaging) {
        if (this.data) {
            this.data.loadPage(nodePaging);
        }
    }

    @Input()
    sorting = ['title', 'asc'];

    @Output()
    showRowContextMenu = new EventEmitter();

    @ViewChild(DataTableComponent)
    dataTable: DataTableComponent;

    data: ShareDataTableAdapter;

    constructor(appConfig: AppConfigService, private thumbnailService: ThumbnailService, private contentService: ContentService,
                private store: Store<AppStore>) {
        super(appConfig, DataTableExtensionComponent.PRESET_KEY, {});
        this.data = new ShareDataTableAdapter(this.thumbnailService, this.contentService, null, null, null);
        this.data.setImageResolver(this.imageResolver);
    }

    ngAfterContentInit() {
        this.createDatatableSchema();
    }

    imageResolver(): string {
        return 'assets/images/baseline-library_books-24px.svg';
    }

    selectRow(event: DataRowEvent) {
        event.value['node'].isLibrary = true;
        this.store.dispatch(new SetSelectedNodesAction([event.value['node']]));
    }
}
