# Alfresco Applications

## Introduction

The repository is based on the [Nx Workspace](https://nx.dev/) and contains the following Alfresco applications and libraries built with Angular and [ADF](https://github.com/Alfresco/alfresco-ng2-components):

- Alfresco Control Center
- Alfresco Digital Workspace (with plugins)

## Project Documentation

- [Alfresco Control Center](./apps/admin-cc/README.md)
- [Alfresco Digital Workspace](./apps/content-ee/README.md)

## Compatibility

| Application | ACS | Node | ADF | Angular |
| --- | --- | --- | --- | --- |
| ACC 8.1 | 7.4 | 18.x | 6.1.0 | 14.x |
| ACC 8.0 | 7.4 | 14.x | 6.0.0 | 14.x |

| Application | ACS | Node | ADF | ACA | Angular |
| --- | --- | --- | --- | --- | --- |
| ADW 4.1 | 7.4 | 18.x | 6.1.0 | 4.1.0 | 14.x |
| ADW 4.0 | 7.4 | 14.x | 6.0.0 | 4.0.0 | 14.x |


## Installing dependencies

Run the following command to install all third-party dependencies:

```bash
npm ci
```

> See also: [Node Version Manager](./developer-docs/nvm.md)

## Environment Variables

Each application requires various environment variables to be set. To see which variables you need to set for an application or its e2e, please refer to the specific app's README.md (which can be found under `./apps/<app-name>/README.md`).  *Between the apps, you may find many overlapping variables with the same value.*

To run/build/test/etc, create an `.env` file in the project root folder:

```bash
VAR_NAME1="<url>"
VAR_NAME2=true
```

## Running an application 

> For VS Code users, it is highly recommended to use [Nx Console](https://marketplace.visualstudio.com/items?itemName=nrwl.angular-console) extension

Use one of the following commands to run the application:

```bash
# Development server
nx serve <admin-cc|content-ee>

# Production server
nx serve <admin-cc|content-ee> -- --prod
```

## Building an application

Use one of the following commands to build the application:

```bash
# develop build
nx build <admin-cc|content-ee>

# Production build
nx build <admin-cc|content-ee> -- --prod
```

## Distributing applications

Run the `pack` command to create a distributable artifacts:

```bash
nx pack admin-cc
nx pack admin-cc --configuration=production

nx pack content-ee
nx pack content-ee --configuration=production
```

Which produces the following output:

```bash
dist/artifacts/alfresco-control-center-7.8.0.sha1
dist/artifacts/alfresco-control-center-7.8.0.zip

dist/artifacts/alfresco-digital-workspace-4.0.0-A.2.sha1
dist/artifacts/alfresco-digital-workspace-4.0.0-A.2.zip
```

To verify the distribution:

```bash
shasum --check alfresco-control-center-7.8.0.sha1
```

## Unit Tests

Use the following command to run the unit tests:

```bash
nx test <project name>
```

## E2E Tests

You might need to update the local distribution of the Playwright

```bash
npx playwright install
```

### Option 1

Launch the corresponding application from the Nx Console interface, or command line:

```bash
nx serve admin-cc
```

Then run the e2e project from the Nx Console interface, or command line:

```bash
nx e2e admin-cc-security-e2e
```

### Option 2

Run the `e2e` target with the `production` flag, to automatically run the suite with the default web server

```bash
nx run admin-cc-content-identity-e2e:e2e --configuration=production
```

### Code Coverage

Use the following command to run tests with code coverage report:

```bash
# Generate code coverage for a specific project
nx test <project name> --codeCoverage

# Generate code coverage for everything
nx affected:test -- --all --code-coverage
```

## Upgrading Dependencies

To upgrade to the latest versions of ADF and ACA dependencies, run the following command:

```shell
npm run adf-update
```

That is an interactive script that allows you to pick from the following options to upgrade:

- ADF libraries
- JS-API library
- ACA libraries

## Release Commits

To perform the release commit, ensure you have a clean repository and run the following command:

```shell
npm run release
```

The process is interactive, and you will be guided through a series of questions:

```text
? The new version for package.json@7.9.0 7.10.0
? The new version of admin-cc (7.9.0) 7.10.0
? The new version of content-ee (4.0.0-A.3) 4.0.0
? Update ADF libraries? Yes
? New version of the ADF libraries (can also be alpha|beta|latest) alpha
? Update JS-API version? Yes
? New version of JS-API (can also be alpha|beta|latest) alpha
? Update ACA libs? Yes
? New version of the ACA libraries (can also be alpha|beta|latest) alpha
? Generate git commit? (y/N)
```

Please provide the answers according to the release plan.

After successful release bump the version and release version in package.json manually.

## Linking ADF

### Using Custom ADF Branches

Clone the ADF repository in the parent folder, so that you have the following structure:

```text
projects
  ├── alfresco-applications
  └── alfresco-ng2-components
```

> You can also use Nx Console UI to run the project with the corresponding configuration.

#### Building

```bash
# developer build
npm run build <project> -- -c adf

# production build
npm run build <project> -- -c adfprod
```

#### Running

```bash
# developer build
npm start <project> -- -c adf

# production build
npm start <project> -- -c adfprod
```

## Linking ACA

### Using Custom ACA Branches

Clone the ACA repository in the parent folder, so that you have the following structure:

```text
projects
  ├── alfresco-applications
  └── alfresco-content-app
```

> You can also use Nx Console UI to run the project with the corresponding configuration.

#### Building

```bash
npm run build <project> -- -c aca
```

#### Running

```bash
npm start <project> -- -c aca
```

### Using Custom ADF Branches with CI/CD

To create a PR that utilises a custom ADF branch, use `[link-adf:<branch>]` text block in the commit message: 

```text
1. [link-adf:develop] Your commit message
2. Your commit message [link-adf:develop]
3. Your [link-adf:develop] commit message
4. [link-adf:develop]
```

Note that the message should be present in every latest commit for your PR to make CI/CD use ADF linking feature.

### Linking localisation resources

In the module directory create an `i18n` folder and add `en.json` with translation keys, i.e. `/libs/<library>/i18n`

Configure `TRANSLATION_PROVIDER` in the module:

```ts
providers: [
    TranslationService,
    {
        provide: TRANSLATION_PROVIDER,
        multi: true,
        useValue: {
            name: '<feature-name>',
            source: `assets/<feature-name>`
        }
    },
]
```

In `apps/<project>/project.json`, configure the assets target to pick the translation keys:

```json
{
  "input": "libs/<library>/i18n",
  "output": "assets/<feature-name>/i18n",
  "glob": "**/*"
}
```

## Release Artifacts

| Project | Docker | Build .zip | Build .war | Sourcecode .zip | Npm |
| :-- | :-: | :-: | :-: | :-: | :-: |
| Content EE | :white_check_mark: | :white_check_mark: *(S3, Nexus)* | :white_check_mark: *(S3)* | :white_check_mark: *(S3, Nexus)* | :white_check_mark: *(extensions)* |
| Admin CC | :white_check_mark: | :white_check_mark: *(S3, Nexus)* | :x: | :x: | :x: |
